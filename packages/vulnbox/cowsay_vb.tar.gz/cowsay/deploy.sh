#!/bin/bash

docker compose up -d --build
docker ps -n 1
