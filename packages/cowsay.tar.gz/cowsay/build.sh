#!/bin/bash

docker build -t cowsay .
