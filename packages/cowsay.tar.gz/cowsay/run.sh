#!/bin/bash

docker run -d -p5000:5000 cowsay
docker ps -n 1
